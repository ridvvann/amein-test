# Videos Directory

This directory contains all the video files for your portfolio website.

## How to add videos:

1. Upload your video files to this directory
2. Add the video information through the admin interface at `/admin`
3. Your videos will automatically appear on the website

## Supported formats:

- MP4 (.mp4)
- WebM (.webm)
- Ogg (.ogg)

For best compatibility across browsers, MP4 format is recommended.

